import sys,time,threading,re
from RepoLibClass import RepoManager


class CLIManagerClass():
    __input_lock = threading.Lock()
    printout = None
    clearout = None
    update_status = None
    def __init__(self,printout,clearout,update_status):
        self.repos = None#RepoManager(printout,update_status)
        CLIManagerClass.printout = printout
        CLIManagerClass.clearout = clearout
        CLIManagerClass.update_status = update_status

        self.__user_response = ''
        self.__user_response_dir = False

        self.__process = threading.Thread(target=self.__process_input_thread(),daemon=True)

    def Start(self,allow_toast):
        self.repos = RepoManager(CLIManagerClass.printout,CLIManagerClass.update_status,allow_toast)
        self.__process.start()


    def user_response(self,text):
        if self.__user_response_dir:
            self.__user_response = text
            CLIManagerClass.__input_lock.release()
        if text != 'resetUI' and not re.match(r'^\d+(?:,\s*\d+)*$',text):return
        self.__user_response = text
        CLIManagerClass.printout('< ' + text + '\n')
        CLIManagerClass.__input_lock.release()
    def input(self,text):
        CLIManagerClass.printout('> ' + text)
        CLIManagerClass.__input_lock.acquire()
        while CLIManagerClass.__input_lock.locked():
            time.sleep(0.1)
        value = self.__user_response
        self.__user_response = ''
        return value
        
    def __process_input_thread(self):
        def run():
            while(True):
                self.__process_input()
                time.sleep(0.5)
        return run
    def __process_input(self):
        CLIManagerClass.update_status(self.repos.current_status)
        if not self.repos.root_directory_set:
            self.__user_response_dir = True
            dir = self.input('Enter root directory for responsitories:\n')
            self.__user_response_dir = False
            self.repos.set_root_directory(dir)
            return
        action = self.input("""\nMain Menu:
    0. Set root directory for repositories
    1. Check all repositories for changes
    2. Pull for certain repositories
    3. Pull for all repositories
What would you like to do? :\n""")
        CLIManagerClass.clearout()
        if action not in ['0','1','2','3']:action = '1'
        try:
            action = int(action)
        except:
            CLIManagerClass.printout('> invalid selection\n')
            return
        CLIManagerClass.update_status('BUSY')
        if action == 0:
            self.__user_response_dir = True
            dir = self.input('Enter root directory for responsitories:\n')
            self.__user_response_dir = False
            self.repos.set_root_directory(dir)
            self.repos.refresh_repo_list()
            CLIManagerClass.clearout()
        if action == 1:
            self.repos.refresh_repo_list()
        if action == 2:
            num_repos = self.repos.display_repos_to_pull()
            if num_repos < 1:
                self.repos.display_all_repos()
                return
            repo_list = []
            repo_list_str = ''
            repo_list_str = self.input('Enter repo numbers to pull separated by commas:\n')
            if repo_list_str == 'resetUI':
                self.repos.display_all_repos()
                return
            try:
                repo_list = repo_list_str.split(',')
                count = 0
                for repo_id in repo_list:
                    repo_list[count] = int(repo_list[count])-1
                    count += 1
            except:
                repo_list = []
                self.repos.display_all_repos()
                return
            if len(repo_list) < 1:
                self.repos.display_all_repos()
                return
            self.repos.pull_some_repos(repo_list)
        if action == 3:
            self.repos.pull_all_repos()
        self.repos.display_all_repos()
        return