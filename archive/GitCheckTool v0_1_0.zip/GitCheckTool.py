import tkinter as tk
from tkinter import scrolledtext
import pystray,time,threading,os
from PIL import Image
from win11toast import toast
from CLIManagager import CLIManagerClass

__version = '1_0_0'


def send_toast(title,content):
    toast(title, content)

cwd = os.getcwd()
   
cli_manager = None

# every 10 minutes, while the program is in the background, check for repo status and push windows notificaitons if an update occurs
window_is_shown = True
__auto_loop_count = 0
icon_settings = {'status':'INIT',
                 'old status':'',
                 'ready':False}

def __set_icon():
    status = icon_settings['status']
    icon_settings['old status'] = status
    txt = 'Repo Status App\nStatus: {}'.format(icon_settings['status'])
    taskbar_icon.title = txt
    taskbar_icon.icon = imgs[status]
    root.iconphoto(True,window_imgs[status])
def __auto_loop():
    global __auto_loop_count
    global cli_manager
    while(True):
        time.sleep(2)
        if icon_settings['ready']:
            __auto_loop_count += 1
            if __auto_loop_count < 2:pass
            elif __auto_loop_count == 2:
                update_status('BUSY')
                __set_icon()
                cli_manager = CLIManagerClass(printout,clearout,update_status)
                cli_manager.Start(not window_is_shown)
            else:
                if __auto_loop_count % 30 == 0:
                    if not window_is_shown:
                        update_status('BUSY')
                        cli_manager.user_response('resetUI')
                if icon_settings['status'] != icon_settings['old status']:
                    __set_icon()
__auto_loop_thread = threading.Thread(target=__auto_loop,daemon=True)
__auto_loop_thread.start()

def show_window(icon=None, item=None):
    global window_is_shown
    window_is_shown = True
    root.after(0, root.deiconify)
    user_entry.focus_set()
    if cli_manager:
        if cli_manager.repos:
            cli_manager.repos.allow_toasts = False
def quit_window(icon=None, item=None):
    root.destroy()
    import sys
    sys.exit(0)
    import os
    os._exit()

def hide_window():
    global window_is_shown
    window_is_shown = False
    root.withdraw()
    if cli_manager:
        if cli_manager.repos:
            cli_manager.repos.allow_toasts = True
def update_status(status):
    if not status:return
    if status == 'SHOW WINDOW':
        show_window()
        return
    icon_settings['status'] = status
    user_entry.focus_set()

imgs = {
    'INIT':Image.open(cwd+'/icons/status_init.png'),
    'GOOD':Image.open(cwd+'/icons/status_good.png'),
    'PUSH':Image.open(cwd+'/icons/status_push.png'),
    'PULL':Image.open(cwd+'/icons/status_pull.png'),
    'BOTH':Image.open(cwd+'/icons/status_both.png'),
    'BUSY':Image.open(cwd+'/icons/status_busy.png')
}
menu = pystray.Menu(
    pystray.MenuItem('Show', show_window),
    pystray.MenuItem('Quit', quit_window)
)
taskbar_icon = pystray.Icon("RepoStatus", imgs['INIT'], "Repo Status App", menu)
taskbar_thread = threading.Thread(target=taskbar_icon.run, daemon=True)
taskbar_thread.start()


root = tk.Tk()
root.title("Repo Status App")
root.geometry("1024x800")
root.attributes('-toolwindow',True)
window_imgs = {
    'INIT':tk.PhotoImage(file=cwd+'/icons/status_init.png'),
    'GOOD':tk.PhotoImage(file=cwd+'/icons/status_good.png'),
    'PUSH':tk.PhotoImage(file=cwd+'/icons/status_push.png'),
    'PULL':tk.PhotoImage(file=cwd+'/icons/status_pull.png'),
    'BOTH':tk.PhotoImage(file=cwd+'/icons/status_both.png'),
    'BUSY':tk.PhotoImage(file=cwd+'/icons/status_busy.png')
}
root.iconphoto(True,window_imgs['INIT'])

# Bind close button to hide window instead of quitting
root.protocol("WM_DELETE_WINDOW", hide_window)

output_text = scrolledtext.ScrolledText(root,wrap=tk.NONE,background='lightgray')
output_text.pack(fill=tk.BOTH, ipady=150, padx=10, pady=5, expand=True)
output_text.tag_config('black',foreground='black')
output_text.tag_config('green',foreground='green',font=('Helvetica',10,'bold'))
output_text.tag_config('blue',foreground='blue',font=('Helvetica',10,'bold'))
output_text.tag_config('orange',foreground='orange',font=('Helvetica',10,'bold'))
output_text.tag_config('red',foreground='red',font=('Helvetica',10,'bold'))

def run_user_entry(*args):
    txt = user_entry.get()
    user_entry.delete(0,tk.END)
    cli_manager.user_response(txt)
user_entry = tk.Entry(root,text='')
user_entry.pack(fill='x', ipady=5, padx=10, pady=5, expand=True)
user_entry.bind('<Return>',run_user_entry)

version_label = tk.Label(root,text='Version {}'.format(__version))
version_label.pack()


def clearout():
    output_text.config(state='normal')
    output_text.delete("1.0",tk.END)
    output_text.config(state='disabled')
def printout(text,color='black'):
    output_text.config(state='normal')
    output_text.insert(tk.END,text,color)
    output_text.config(state='disabled')


icon_settings['ready'] = True
hide_window()
root.mainloop()
